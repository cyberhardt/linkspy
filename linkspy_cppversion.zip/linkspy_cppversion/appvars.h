#ifndef APPVARS_H
#define APPVARS_H

#include <QString>

// Application variables
#define APPNAME "linkspy"
#define CURRVER 20181105
#define APPVER "3.0"

#endif // APPVARS_H
